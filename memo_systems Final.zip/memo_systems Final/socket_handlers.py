from app import socketio
from flask_socketio import join_room

@socketio.on("join")
def handle_join(data):
    room = data.get("room")
    if room:
        join_room(room)
        socketio.emit("joined", {"room": room}, room=room)