# db_diagnostics.py
import traceback
from app import get_conn
import sqlite3
from datetime import datetime

def print_div(s):
    print("\n" + "="*10 + " " + s + " " + "="*10 + "\n")

def schema_info(conn, table):
    cur = conn.cursor()
    cur.execute(f"PRAGMA table_info({table})")
    rows = cur.fetchall()
    print(f"Schema for {table}:")
    for r in rows:
        print(dict(r))
    print()

def pragma_info(conn):
    cur = conn.cursor()
    for p in ("journal_mode","synchronous","foreign_keys","wal_autocheckpoint"):
        try:
            cur.execute(f"PRAGMA {p};")
            print(f"PRAGMA {p} =>", cur.fetchone())
        except Exception:
            pass
    cur.execute("PRAGMA page_count;")
    print("page_count:", cur.fetchone())
    cur.execute("PRAGMA page_size;")
    print("page_size:", cur.fetchone())

def integrity_check(conn):
    cur = conn.cursor()
    try:
        cur.execute("PRAGMA integrity_check;")
        print("integrity_check:", cur.fetchone()[0])
    except Exception as e:
        print("integrity_check error:", e)

def recent_rows(conn, table, limit=10):
    cur = conn.cursor()
    try:
        cur.execute(f"SELECT ROWID, * FROM {table} ORDER BY ROWID DESC LIMIT ?", (limit,))
        rows = cur.fetchall()
        print(f"Last {limit} rows from {table}:")
        for r in rows:
            print(dict(r))
    except Exception as e:
        print(f"Cannot read {table}:", e)

def try_test_insert(conn):
    # Try to perform the same INSERT used by the app, in a transaction then rollback,
    # so we can see the sqlite error without modifying DB.
    cur = conn.cursor()
    serial_code = f"TEST-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
    try:
        cur.execute("BEGIN")
        cur.execute("""
            INSERT INTO system_ledger (
                serial_code, issue_date, department, origin_department,
                recipient, recipient_personnel, subject, body, priority_level, cc_list, signature_name
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            serial_code,
            datetime.utcnow().strftime('%Y-%m-%d'),
            "DIAG-DEPT",
            "DIAG",
            "RR",
            "",
            "DIAGNOSTIC INSERT",
            "This is a diagnostic insert",
            "ROUTINE",
            "",
            "diagnostic"
        ))
        # attempt commit to see if sqlite raises here
        conn.commit()
        print("Test insert committed successfully (unexpected). Rolling back test insert.")
        # if commit succeeded, delete the test row to keep DB clean
        cur.execute("DELETE FROM system_ledger WHERE serial_code = ?", (serial_code,))
        conn.commit()
    except sqlite3.IntegrityError as ei:
        print("sqlite3.IntegrityError:", ei)
        conn.rollback()
    except sqlite3.OperationalError as eo:
        print("sqlite3.OperationalError:", eo)
        traceback.print_exc()
        conn.rollback()
    except Exception as e:
        print("Other Exception during test insert:", e)
        traceback.print_exc()
        conn.rollback()

def main():
    conn = get_conn()
    try:
        print_div("PRAGMA info")
        pragma_info(conn)
        print_div("INTEGRITY CHECK")
        integrity_check(conn)
        print_div("SCHEMAS")
        schema_info(conn, "system_ledger")
        schema_info(conn, "accounts")
        schema_info(conn, "cc_signatures")
        print_div("RECENT ROWS")
        recent_rows(conn, "system_ledger", limit=5)
        print_div("TRY TEST INSERT (will rollback on error)")
        try_test_insert(conn)
    finally:
        try:
            conn.close()
        except Exception:
            pass

if __name__ == "__main__":
    main()