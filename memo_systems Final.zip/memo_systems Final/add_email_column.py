#!/usr/bin/env python3
"""
add_email_column.py

Safely add an 'email' column to the 'accounts' table in hospital_ledger.db.

Behavior:
- Verifies that hospital_ledger.db exists in the current directory (or change db variable).
- Creates a timestamped backup before making schema changes.
- Checks whether the 'email' column already exists; only runs ALTER TABLE if missing.
- Prints progress and exits cleanly.

Usage:
  # Run in the directory that contains hospital_ledger.db:
  python add_email_column.py

  # If your DB is elsewhere, edit the `db` variable below or run the script from the DB directory.
"""
from __future__ import annotations
import os
import sqlite3
import shutil
from datetime import datetime
import sys

db = "hospital_ledger.db"

if not os.path.isfile(db):
    print(f"ERROR: DB not found at {os.path.abspath(db)}", file=sys.stderr)
    raise SystemExit(1)

# Create a timestamped backup
ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
bak = f"{db}.bak.{ts}"
try:
    shutil.copy2(db, bak)
    print("Backup created:", bak)
except Exception as e:
    print("ERROR: failed to create backup:", e, file=sys.stderr)
    raise SystemExit(2)

# Open DB and check/add column
try:
    conn = sqlite3.connect(db)
    cur = conn.cursor()
    cur.execute("PRAGMA table_info(accounts)")
    cols = [r[1] for r in cur.fetchall()]
    if "email" in cols:
        print("Email column already exists. No changes made.")
    else:
        cur.execute("ALTER TABLE accounts ADD COLUMN email TEXT")
        conn.commit()
        print("Email column added successfully.")
except sqlite3.OperationalError as oe:
    print("SQLite operational error:", oe, file=sys.stderr)
    # Attempt to restore backup if something went wrong during ALTER
    try:
        shutil.copy2(bak, db)
        print("Restored DB from backup:", bak)
    except Exception as re:
        print("ERROR: failed to restore DB from backup:", re, file=sys.stderr)
    raise SystemExit(3)
except Exception as e:
    print("Unexpected error:", e, file=sys.stderr)
    raise SystemExit(4)
finally:
    try:
        conn.close()
    except Exception:
        pass

print("Done.")