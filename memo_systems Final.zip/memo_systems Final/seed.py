# seed.py
"""
Seed demo accounts and one memo for the monolithic app.py (sqlite) you already have.
Uses get_conn() from app.py so you don't need SQLAlchemy.

Run:
    python seed.py
"""
import sqlite3
from werkzeug.security import generate_password_hash
from app import get_conn  # uses the get_conn defined in your monolithic app.py

def ensure_account(conn, username, password, role='SEC', email=None, phone=None):
    cur = conn.cursor()
    cur.execute("SELECT id FROM accounts WHERE username = ?", (username,))
    row = cur.fetchone()
    if row:
        return row[0]
    pw_hash = generate_password_hash(password)
    cur.execute(
        "INSERT INTO accounts (username, password_hash, role, email, phone) VALUES (?, ?, ?, ?, ?)",
        (username, pw_hash, role, email, phone)
    )
    conn.commit()
    return cur.lastrowid

def ensure_memo(conn, subject, origin_department='MED', recipient='RR', body='Demo memo body', cc_list=''):
    cur = conn.cursor()
    cur.execute("SELECT serial_code FROM system_ledger WHERE subject = ?", (subject,))
    if cur.fetchone():
        return None
    # generate a simple serial code; keep uniqueness by timestamp if required
    from datetime import datetime
    stamp = datetime.utcnow().strftime('%Y%m%d%H%M%S')
    serial_code = f"MEMO-{origin_department}-{stamp}"
    cur.execute("""
        INSERT INTO system_ledger (
            serial_code, issue_date, department, origin_department, recipient,
            recipient_personnel, subject, body, priority_level, cc_list, signature_name
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        serial_code,
        datetime.utcnow().strftime('%Y-%m-%d'),
        origin_department,
        origin_department,
        recipient,
        '',
        subject,
        body,
        'ROUTINE',
        cc_list,
        ''
    ))
    conn.commit()
    return serial_code

def list_accounts(conn):
    cur = conn.cursor()
    cur.execute("SELECT id, username, role, email, phone FROM accounts ORDER BY id")
    return cur.fetchall()

def list_memos(conn, limit=10):
    cur = conn.cursor()
    cur.execute("SELECT serial_code, issue_date, origin_department, recipient, subject FROM system_ledger ORDER BY ROWID DESC LIMIT ?", (limit,))
    return cur.fetchall()

def main():
    conn = get_conn()
    try:
        # create demo accounts
        print("Seeding accounts...")
        sec_id = ensure_account(conn, "secretary", "secretarypass", role="SEC", email="sec@example.local", phone="250700000001")
        origin_id = ensure_account(conn, "origin_user", "originpass", role="MED", email="origin@example.local", phone="250700000002")
        alice_id = ensure_account(conn, "alice", "alicepass", role="CC", email="alice@example.local", phone="250700000003")

        print(f"Accounts ensured: secretary id={sec_id}, origin_user id={origin_id}, alice id={alice_id}")

        # create a demo memo if not present
        print("Seeding a demo memo...")
        serial = ensure_memo(conn, subject="Demo: Please approve this memo", origin_department="MED", recipient="RR", body="This is a demo memo created by seed.py", cc_list="CC")
        if serial:
            print(f"Inserted memo with serial_code: {serial}")
        else:
            print("Memo with same subject already exists; skipped insert.")

        # list accounts and memos
        print("\nCurrent accounts:")
        for row in list_accounts(conn):
            print(f"  id={row[0]} username={row[1]} role={row[2]} email={row[3]} phone={row[4]}")

        print("\nRecent memos:")
        for m in list_memos(conn, limit=10):
            print(f"  serial={m[0]} date={m[1]} origin={m[2]} recipient={m[3]} subject={m[4]}")
    finally:
        conn.close()

if __name__ == "__main__":
    main()