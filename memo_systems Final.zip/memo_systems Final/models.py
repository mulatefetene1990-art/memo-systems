from app import db
from datetime import datetime

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(255))
    department = db.Column(db.String(50))  # department code (e.g., MED)
    def to_dict(self):
        return {"id": self.id, "username": self.username, "email": self.email, "department": self.department}

class Draft(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    subject = db.Column(db.String(255), nullable=False)
    body = db.Column(db.Text)
    origin = db.Column(db.String(50))  # department code (FROM)
    status = db.Column(db.String(50), default="draft")  # draft, pending_approval, approved
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)
    def to_dict(self):
        return {"id": self.id, "subject": self.subject, "body": self.body, "origin": self.origin, "status": self.status}

class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    draft_id = db.Column(db.Integer, db.ForeignKey('draft.id'), nullable=True)
    message = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    read = db.Column(db.Boolean, default=False)

    user = db.relationship('User', backref='notifications')
    draft = db.relationship('Draft', backref='notifications')

    def to_dict(self):
        return {"id": self.id, "user_id": self.user_id, "draft_id": self.draft_id, "message": self.message, "created_at": self.created_at.isoformat(), "read": self.read}