# add to routes.py (append)
import os, json
from flask import request, jsonify
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TELEGRAM_MAP_PATH = os.path.join(BASE_DIR, "department_to_telegram.json")

def _load_telegram_map():
    try:
        with open(TELEGRAM_MAP_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def _save_telegram_map(mapping):
    with open(TELEGRAM_MAP_PATH, "w", encoding="utf-8") as f:
        json.dump(mapping, f, indent=2, ensure_ascii=False)

def _is_admin_request():
    # Preferred: require ADMIN_SECRET in X-ADMIN-SECRET header
    admin_secret = os.environ.get("ADMIN_SECRET")
    if admin_secret:
        header = request.headers.get("X-ADMIN-SECRET", "")
        return header == admin_secret
    # Fallback (dev): allow demo "secretary" session user
    from auth import get_current_user
    user = get_current_user()
    return bool(user and getattr(user, "username", "") == "secretary")

@app.route("/admin/department-telegram", methods=["GET"])
def admin_get_department_telegram():
    if not _is_admin_request():
        return jsonify({"ok": False, "error": "admin auth required"}), 403
    return jsonify({"ok": True, "mapping": _load_telegram_map()})

@app.route("/admin/set-dept-telegram", methods=["POST"])
def admin_set_dept_telegram():
    """
    JSON: {"dept": "RECORD_ROOM", "chat": "-1001234567890"}
    """
    if not _is_admin_request():
        return jsonify({"ok": False, "error": "admin auth required"}), 403
    data = request.get_json() or {}
    dept = data.get("dept")
    chat = data.get("chat")
    if not dept or not chat:
        return jsonify({"ok": False, "error": "dept and chat are required"}), 400
    m = _load_telegram_map()
    m[dept] = str(chat)
    _save_telegram_map(m)
    return jsonify({"ok": True, "mapping": {dept: m[dept]}})