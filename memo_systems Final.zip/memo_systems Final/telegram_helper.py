import os
import requests

def _get_env_bool(name):
    return os.environ.get(name, "0") not in ("0", "", "false", "False")

TELEGRAM_ENABLED = _get_env_bool("TELEGRAM_ENABLED")  # set "1" to enable real sends
TELEGRAM_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")

def send_telegram_message(chat_id, text):
    """
    Sends a Telegram message if enabled. Otherwise prints a stub message.
    chat_id can be numeric string (e.g., "-100123...") or username.
    """
    if not TELEGRAM_ENABLED:
        print(f"[telegram stub] to {chat_id}: {text}")
        return {"ok": True, "stub": True}

    if not TELEGRAM_TOKEN:
        raise RuntimeError("TELEGRAM_BOT_TOKEN env var is not set but TELEGRAM_ENABLED=1")

    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}
    resp = requests.post(url, data=payload, timeout=10)
    try:
        return resp.json()
    except Exception:
        return {"ok": False, "status_code": resp.status_code, "text": resp.text}