# admin endpoints to view/update department_to_users.json
import os
import json
from flask import request, jsonify, current_app

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DEPT_USERS_PATH = os.path.join(BASE_DIR, "department_to_users.json")

def _load_dept_users():
    try:
        with open(DEPT_USERS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def _save_dept_users(mapping):
    with open(DEPT_USERS_PATH, "w", encoding="utf-8") as f:
        json.dump(mapping, f, indent=2, ensure_ascii=False)
    return True

def _is_admin_request():
    # Prefer ADMIN_SECRET for server-to-server admin calls
    admin_secret = os.environ.get("ADMIN_SECRET")
    if admin_secret:
        header = request.headers.get("X-ADMIN-SECRET", "")
        return header == admin_secret
    # Fallback: allow if logged-in user has username "secretary" (demo-only)
    from auth import get_current_user
    user = get_current_user()
    if user and getattr(user, "username", "") == "secretary":
        return True
    return False

@app.route("/admin/department-mapping", methods=["GET"])
def admin_get_department_mapping():
    if not _is_admin_request():
        return jsonify({"ok": False, "error": "admin auth required"}), 403
    mapping = _load_dept_users()
    return jsonify({"ok": True, "mapping": mapping})

@app.route("/admin/set-dept-users", methods=["POST"])
def admin_set_dept_users():
    """
    Body JSON: { "dept": "MED", "users": [2,3,4] }
    Requires admin auth (see _is_admin_request).
    """
    if not _is_admin_request():
        return jsonify({"ok": False, "error": "admin auth required"}), 403

    data = request.get_json() or {}
    dept = data.get("dept")
    users = data.get("users")

    if not dept or users is None:
        return jsonify({"ok": False, "error": "dept and users are required"}), 400

    # validate users is a list of ints
    if not isinstance(users, list) or not all(isinstance(u, int) for u in users):
        return jsonify({"ok": False, "error": "users must be a list of integer user ids"}), 400

    mapping = _load_dept_users()
    mapping[dept] = users
    _save_dept_users(mapping)
    return jsonify({"ok": True, "mapping": mapping[dept]})