#!/usr/bin/env python3
"""
reset_pw.py

Safe, standalone utility to reset a user's password in hospital_ledger.db.

Features:
- Makes a timestamped backup of the database before changing anything.
- Verifies the target user exists.
- Accepts --db, --username and optional --password (if not provided, prompts securely).
- Uses werkzeug.generate_password_hash to create a secure hash compatible with your app.
- Prints a short verification SELECT after the update.

Usage examples:
  # Interactive (prompts for password)
  python reset_pw.py --username alice

  # Non-interactive (provide password on command line)
  python reset_pw.py --username alice --password "NewSecret123"

  # Specify a different DB path
  python reset_pw.py --db /path/to/hospital_ledger.db --username alice

Note: Run this on the machine that has access to hospital_ledger.db (or point --db to a mounted path).
"""

import os
import sys
import argparse
import shutil
import sqlite3
from getpass import getpass
from datetime import datetime

try:
    from werkzeug.security import generate_password_hash
except Exception:
    print("ERROR: werkzeug is required. Install with: pip install werkzeug")
    sys.exit(1)


def backup_db(db_path):
    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    dirn, base = os.path.split(db_path)
    backup_name = f"{base}.bak.{ts}"
    backup_path = os.path.join(dirn or ".", backup_name)
    shutil.copy2(db_path, backup_path)
    return backup_path


def user_exists(conn, username):
    cur = conn.cursor()
    cur.execute("SELECT 1 FROM accounts WHERE username = ? LIMIT 1", (username,))
    return cur.fetchone() is not None


def update_password(conn, username, hash_value):
    cur = conn.cursor()
    cur.execute("UPDATE accounts SET password_hash = ? WHERE username = ?", (hash_value, username))
    conn.commit()
    return cur.rowcount  # number of rows updated


def show_user_row(conn, username):
    cur = conn.cursor()
    cur.execute("SELECT id, username, role, email FROM accounts WHERE username = ?", (username,))
    return cur.fetchone()


def parse_args():
    p = argparse.ArgumentParser(description="Reset a user's password in hospital_ledger.db")
    p.add_argument("--db", "-d", default="hospital_ledger.db", help="Path to SQLite DB file (default: hospital_ledger.db)")
    p.add_argument("--username", "-u", required=True, help="Username to reset")
    p.add_argument("--password", "-p", help="New password. If omitted, will prompt interactively.")
    p.add_argument("--no-backup", action="store_true", help="Do not create a backup copy of the DB (not recommended).")
    return p.parse_args()


def main():
    args = parse_args()
    db_path = args.db
    username = args.username.strip()

    if not os.path.isfile(db_path):
        print(f"ERROR: database file not found at: {db_path}")
        sys.exit(2)

    # Prompt for password if not provided
    if args.password:
        new_pass = args.password
    else:
        new_pass = getpass("New password: ").strip()
        confirm = getpass("Confirm new password: ").strip()
        if new_pass != confirm:
            print("ERROR: Passwords do not match. Aborting.")
            sys.exit(3)
        if not new_pass:
            print("ERROR: Password cannot be empty.")
            sys.exit(4)

    # Backup DB
    backup_path = None
    try:
        if not args.no_backup:
            backup_path = backup_db(db_path)
            print(f"Backup created: {backup_path}")
        else:
            print("Skipping DB backup (--no-backup set).")
    except Exception as e:
        print(f"ERROR: failed to create DB backup: {e}")
        sys.exit(5)

    # Connect and verify user
    try:
        conn = sqlite3.connect(db_path)
    except Exception as e:
        print(f"ERROR: could not open DB: {e}")
        sys.exit(6)

    try:
        if not user_exists(conn, username):
            print(f"ERROR: username '{username}' not found in accounts table.")
            conn.close()
            # Optionally restore from backup? We did no DB changes yet.
            sys.exit(7)

        # Generate hash and update
        hash_value = generate_password_hash(new_pass)
        updated = update_password(conn, username, hash_value)
        if updated:
            print(f"Password updated for user: {username}")
        else:
            print(f"WARNING: No rows updated for user {username} (unexpected).")

        # Show verification row
        row = show_user_row(conn, username)
        if row:
            print("Verification (id, username, role, email):", tuple(row))
        else:
            print("WARNING: could not fetch user row after update.")
    except Exception as e:
        print(f"ERROR: exception during DB operation: {e}")
        # Attempt to restore from backup if available
        if backup_path:
            try:
                shutil.copy2(backup_path, db_path)
                print(f"Restored DB from backup: {backup_path}")
            except Exception as re:
                print(f"ERROR: failed to restore DB from backup: {re}")
        sys.exit(8)
    finally:
        conn.close()


if __name__ == "__main__":
    main()