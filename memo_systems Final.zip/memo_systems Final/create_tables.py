#!/usr/bin/env python3
"""
Idempotent DB initializer for hospital_ledger app.
Usage:
  # default (current dir):
  python create_tables.py

  # target specific path:
  DB_PATH=/full/path/to/hospital_ledger.db python create_tables.py
"""
import os, sqlite3, shutil, sys
from datetime import datetime

DB_PATH = os.environ.get('DB_PATH', 'hospital_ledger.db')

if not os.path.exists(DB_PATH):
    # create empty file
    open(DB_PATH, 'a').close()
    print("Created DB file:", DB_PATH)

# backup
ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
bak = f"{DB_PATH}.bak.{ts}"
shutil.copy2(DB_PATH, bak)
print("Backup created:", bak)

conn = sqlite3.connect(DB_PATH)
cur = conn.cursor()

# create accounts if missing (email column included)
cur.execute("""
CREATE TABLE IF NOT EXISTS accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password_hash TEXT,
    role TEXT,
    email TEXT
)
""")

# create system_ledger
cur.execute("""
CREATE TABLE IF NOT EXISTS system_ledger (
    serial_code TEXT PRIMARY KEY,
    issue_date TEXT,
    department TEXT,
    origin_department TEXT,
    recipient TEXT,
    recipient_personnel TEXT,
    subject TEXT,
    body TEXT,
    priority_level TEXT,
    cc_list TEXT,
    signature_name TEXT,
    approved_by_hr INTEGER DEFAULT 0,
    approved_by_ceo INTEGER DEFAULT 0
)
""")

# create cc_signatures
cur.execute("""
CREATE TABLE IF NOT EXISTS cc_signatures (
    serial_code TEXT,
    department_code TEXT,
    timestamp TEXT,
    PRIMARY KEY (serial_code, department_code)
)
""")

conn.commit()
print("Ensured tables: accounts, system_ledger, cc_signatures")
# show columns for accounts
cur.execute("PRAGMA table_info(accounts);")
print("accounts table columns:", [r[1] for r in cur.fetchall()])
conn.close()
print("Done. DB at:", os.path.abspath(DB_PATH))