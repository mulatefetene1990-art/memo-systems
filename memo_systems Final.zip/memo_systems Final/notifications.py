# in notifications.py (or telegram_map_helper.py)
import os, json

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TELEGRAM_MAP_PATH = os.path.join(BASE_DIR, "department_to_telegram.json")

def _load_telegram_map():
    try:
        with open(TELEGRAM_MAP_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def get_department_telegram(dept_code):
    """
    Returns the chat id or username string for the dept_code, or None.
    """
    mapping = _load_telegram_map()
    return mapping.get(dept_code)