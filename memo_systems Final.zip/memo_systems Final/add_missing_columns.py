# add_missing_columns.py
from app import get_conn
import sqlite3

def ensure_column(conn, table, column, coltype="TEXT"):
    cur = conn.cursor()
    cur.execute(f"PRAGMA table_info({table})")
    cols = [row['name'] for row in cur.fetchall()]
    if column in cols:
        print(f"{table}.{column} already exists")
        return False
    try:
        cur.execute(f"ALTER TABLE {table} ADD COLUMN {column} {coltype}")
        conn.commit()
        print(f"Added column {table}.{column} {coltype}")
        return True
    except sqlite3.OperationalError as e:
        print("Failed to add column:", e)
        return False

def main():
    conn = get_conn()
    try:
        ensure_column(conn, "accounts", "phone", "TEXT")
        # If you expect other new columns in other tables, add them here:
        # ensure_column(conn, "accounts", "another_column", "INTEGER")
    finally:
        conn.close()

if __name__ == "__main__":
    main()