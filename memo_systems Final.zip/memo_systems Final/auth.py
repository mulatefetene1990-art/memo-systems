from flask import session
from models import User

def login_user(user_id):
    session['user_id'] = user_id

def logout_user():
    session.pop('user_id', None)

def get_current_user():
    uid = session.get('user_id')
    if not uid:
        return None
    return User.query.get(uid)