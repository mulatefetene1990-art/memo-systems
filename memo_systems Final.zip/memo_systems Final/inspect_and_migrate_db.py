#!/usr/bin/env python3
"""
migrate_add_email_interactive.py

Interactive helper to inspect / add an 'email' column to the 'accounts' table
in a hospital_ledger.db SQLite database.

Usage:
  python migrate_add_email_interactive.py
  python migrate_add_email_interactive.py --path /path/to/hospital_ledger.db
  python migrate_add_email_interactive.py --search-root /some/search/root  # scans for files named hospital_ledger.db

The script will:
 - Let you specify the DB file or search for candidates
 - Show the 'accounts' table columns
 - Create a timestamped backup before ALTER (unless you cancel)
 - Add the 'email' column if missing and verify
"""
from __future__ import annotations
import os, sys, sqlite3, shutil, argparse
from datetime import datetime

def find_dbs(search_root: str, max_find=200):
    matches = []
    for root, dirs, files in os.walk(search_root):
        if 'hospital_ledger.db' in files:
            matches.append(os.path.join(root, 'hospital_ledger.db'))
            if len(matches) >= max_find:
                break
    return matches

def backup(db_path: str) -> str:
    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    dirn, base = os.path.split(os.path.abspath(db_path))
    bak = os.path.join(dirn or ".", f"{base}.bak.{ts}")
    shutil.copy2(db_path, bak)
    return bak

def show_table_info(db_path: str):
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
    tables = [r[0] for r in cur.fetchall()]
    print("\nTables in DB:", tables)
    if 'accounts' in tables:
        cur.execute("PRAGMA table_info(accounts);")
        rows = cur.fetchall()
        print("accounts columns (cid, name, type, notnull, dflt_value, pk):")
        for r in rows:
            print(" ", r)
    else:
        print("No 'accounts' table found in this DB.")
    conn.close()

def add_email_column(db_path: str):
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("PRAGMA table_info(accounts);")
    cols = [r[1] for r in cur.fetchall()]
    if 'email' in cols:
        print("-> 'email' column already exists. No changes needed.")
        conn.close()
        return True
    print("-> 'email' column missing. Proceeding to add it now.")
    conn.close()
    bak = backup(db_path)
    print("Backup created at:", bak)
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("ALTER TABLE accounts ADD COLUMN email TEXT;")
    conn.commit()
    cur.execute("PRAGMA table_info(accounts);")
    cols2 = [r[1] for r in cur.fetchall()]
    conn.close()
    print("Now accounts columns:", cols2)
    return 'email' in cols2

def choose_db_interactive(args):
    if args.path:
        if os.path.isfile(args.path):
            return os.path.abspath(args.path)
        else:
            print("Provided path not found:", args.path)
            return None

    # Default: check CWD first
    cwd_db = os.path.join(os.getcwd(), 'hospital_ledger.db')
    if os.path.isfile(cwd_db):
        print("Found hospital_ledger.db in current directory:", cwd_db)
        use = input("Use this file? [Y/n]: ").strip().lower() or 'y'
        if use.startswith('y'):
            return os.path.abspath(cwd_db)

    # Ask user for action
    print("\nOptions:")
    print("  1) Enter full path to hospital_ledger.db")
    print("  2) Search for hospital_ledger.db under a directory (may be slow)")
    print("  3) Quit")
    choice = input("Choose 1/2/3: ").strip()
    if choice == '1':
        p = input("Enter full path: ").strip()
        return os.path.abspath(p) if os.path.isfile(p) else None
    if choice == '2':
        root = input("Enter search root (default '/'): ").strip() or '/'
        print("Searching (this can take time)...")
        matches = find_dbs(root)
        if not matches:
            print("No hospital_ledger.db found under", root)
            return None
        print("\nFound files:")
        for i, m in enumerate(matches, 1):
            print(f" {i}) {m}")
        sel = input(f"Select file number (1-{len(matches)}), or 'q': ").strip()
        if sel.lower() == 'q':
            return None
        try:
            idx = int(sel) - 1
            if 0 <= idx < len(matches):
                return matches[idx]
        except Exception:
            return None
    return None

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--path", "-p", help="Direct path to hospital_ledger.db")
    parser.add_argument("--search-root", help="(Deprecated) search root")
    args = parser.parse_args()

    print("STOP your Flask app or container before running this script to avoid DB locks.")
    db_path = choose_db_interactive(args)
    if not db_path:
        print("No DB selected. Exiting.")
        sys.exit(1)

    print("\nInspecting DB:", db_path)
    show_table_info(db_path)

    proceed = input("\nAdd 'email' column to this DB if missing? [y/N]: ").strip().lower() or 'n'
    if not proceed.startswith('y'):
        print("Cancelled by user. Exiting.")
        sys.exit(0)

    try:
        success = add_email_column(db_path)
        if success:
            print("\nSuccess: 'email' column is now present.")
            print("Restart your Flask app and test the forgot-username / forgot-password flows.")
        else:
            print("\nFailed to add 'email' column.")
    except sqlite3.OperationalError as e:
        print("SQLite OperationalError:", e)
        print("If you see 'database is locked', stop the Flask app or other processes and retry.")
    except Exception as e:
        print("Unexpected error:", e)

if __name__ == '__main__':
    main()