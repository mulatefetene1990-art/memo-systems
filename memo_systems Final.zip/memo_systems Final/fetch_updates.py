#!/usr/bin/env python3
"""
fetch_updates.py — helper to pull getUpdates from Telegram bot and save username->chat_id.
Set TELEGRAM_BOT_TOKEN in environment before running.
"""
import os
import requests
import json
import sys

TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
if not TOKEN:
    print("Please set TELEGRAM_BOT_TOKEN env var")
    sys.exit(1)

OUT_FILE = "username_to_chat.json"

def fetch_updates(token):
    url = f"https://api.telegram.org/bot{token}/getUpdates"
    resp = requests.get(url, timeout=10)
    resp.raise_for_status()
    return resp.json()

def extract_user_map(updates_json):
    mapping = {}
    for item in updates_json.get("result", []):
        msg = item.get("message") or item.get("edited_message") or item.get("channel_post") or {}
        if not msg:
            continue
        frm = msg.get("from") or {}
        chat = msg.get("chat") or {}
        username = frm.get("username") or chat.get("username")
        chat_id = chat.get("id") or frm.get("id")
        if username and chat_id:
            mapping[username] = str(chat_id)
    return mapping

def main():
    data = fetch_updates(TOKEN)
    mapping = extract_user_map(data)
    if not mapping:
        print("No username mappings found in getUpdates. Ensure users have messaged your bot.")
    try:
        with open(OUT_FILE, "r", encoding="utf-8") as f:
            existing = json.load(f)
    except Exception:
        existing = {}
    existing.update(mapping)
    with open(OUT_FILE, "w", encoding="utf-8") as f:
        json.dump(existing, f, indent=2, ensure_ascii=False)
    print(f"Wrote {len(mapping)} new username mappings to {OUT_FILE}")
    for k, v in mapping.items():
        print(f"  {k} -> {v}")

if __name__ == "__main__":
    main()